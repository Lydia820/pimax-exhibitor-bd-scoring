# Excel output schema

Create one Chinese `.xlsx` workbook with two worksheets in this order:

1. `全名单`
2. `评分标准`

The default design is a consolidated comparison workbook. Do not create separate priority, profile, contact, raw-data, or dashboard worksheets unless the user explicitly asks for them.

## 1. 全名单

Purpose: let an overseas-marketing or BD reader compare every company without jumping between tabs or opening external links merely to understand the business.

Use one row per reconciled entity. Exact duplicate source rows may share one entity row only when the reconciliation is recorded; otherwise retain separate rows. Sort by total score descending; break ties by research confidence, then company name or event actionability. Add filters, freeze the header and identity/description columns, wrap long text, and use restrained conditional formatting for grades and blocked records.

### Required columns and order

#### Identity and business description

1. 排名
2. 企业名称
3. 企业中文概述
4. 公开业务描述（中文完整翻译）
5. 公开业务描述（英文原文）

The three description columns must remain adjacent. `企业中文概述` is concise and decision-readable. The translation column is a complete Chinese translation of the retained English public description, not a second short summary. If no reliable English source exists, state that explicitly without deleting the Chinese overview or blocker explanation.

#### Ranking and classification

6. 等级
7. 总分
8. 人工评判分类
9. 评分状态
10. 研究置信度
11. 研究状态
12. 企业类型
13. 核心产品或业务
14. 主要市场
15. 合作方向
16. 价值目标
17. 竞争关系

Recommended `人工评判分类` values:

- 优先推进
- 进一步评估或接触
- 项目触发或有条件推进
- 未发现明确合作路径
- 资料不足待人工判断

#### Cooperation decision

18. 评分理由
19. 推荐合作理由
20. 建议切入点
21. 下一步动作
22. 风险及待核实项

When no clear cooperation path exists, say so directly while still explaining the verified business. Do not replace the company introduction with “不相关”. Separate verified facts from Pimax-side inference.

#### Public contacts and channels

23. 联系人明细
24. 公开工作邮箱
25. 公开商务电话
26. LinkedIn人选
27. LinkedIn公司页
28. 联系人/渠道状态

Use line breaks for multiple contacts or channels in one company row. Preserve every public professional contact found at reasonable research depth. A typical contact line is:

`姓名｜当前职位｜公开工作邮箱｜公开商务电话｜LinkedIn`.

Use contact statuses such as:

- `公开来源已确认：具名联系人 N 位；邮箱未做投递验证`
- `源表候选，任职待复核`
- `低置信候选，勿直接录入`
- `仅公司公开商务渠道；未找到具名联系人`
- `目标职位待确认：…`
- `未找到公开联系人`

Never infer personal details or imply that a published email has been deliverability-tested. Keep source-only candidates in `联系人明细` with their warning; do not place them in `公开工作邮箱 / 公开商务电话` unless a public source independently confirms them or the user explicitly requests the supplied historical contact fields in those columns.

#### Sources

29. 官网
30. 关键证据链接
31. 联系来源
32. 核实日期

Multiple source URLs may share a cell separated by line breaks. Keep dates typed and sortable.

### Default omissions

Do not include booth number, hall, exhibitor zone, event logistics, or duplicate raw fields unless the user requests them. Retain source keys and omitted fields in working data for reconciliation.

### Research-state handling

Allowed values:

- `深度核实`
- `标准核实`
- `受阻`
- `仅初筛` only during work in progress

A complete run must have `仅初筛=0`. A blocked row must include a specific reason and attempted source, not a generic batch placeholder.

Allowed score states:

- `正式`
- `暂定`

Every row receives a total and grade for the default complete-ranking workflow. Blocked rows must be visibly `暂定 + 低置信度` and use only a conservative evidence-supported provisional score.

## 2. 评分标准

Keep this worksheet compact and readable. Include:

- total company count and confirmation that all companies appear in `全名单`;
- source-row count, unique-entity count, and consolidated duplicate count;
- sort order;
- A/B/C/D counts;
- `深度核实 / 标准核实 / 受阻 / 仅初筛` counts;
- public named-contact and work-email counts when contacts were requested;
- number of retained English public descriptions and completed Chinese translations;
- the six dimensions and weights;
- 0–5 rating meanings;
- A/B/C/D thresholds;
- definitions of score status, research confidence, research status, and competition labels;
- contact/privacy limitations and email-deliverability warning;
- material limitations and blocked-source explanation.

## Controlled labels

### Company type

- VR游戏或内容
- VRChat或社交VR
- 模拟赛车
- 模拟飞行
- 驾驶舱或座椅
- 控制器或模拟外设
- 动感平台或触觉设备
- VR场馆或线下娱乐
- 街机或游乐设备
- 系统集成商
- 企业解决方案
- 经销商或渠道商
- PC或相关硬件生态
- 社区或媒体
- 赛事或活动方
- 技术或供应链
- VR头显厂商
- 其他相关
- 暂无明显关联
- 待确认

### Cooperation lane

- 产品兼容或联合测试
- 捆绑销售
- 渠道或经销合作
- 互相推荐或导流
- Affiliate或分成合作
- 联合内容
- 社区联合活动
- 展会或线下演示
- 场馆或解决方案集成
- OEM或技术合作
- 联合营销
- 企业采购
- 竞合审查
- 暂无明确路径
- 待确认

### Value goal

- 订单
- 流量
- Leads
- 品牌曝光
- 渠道覆盖
- 生态互补
- 产品体验或兼容性
- 市场情报

Multiple labels may share a cell separated by `；`. Keep each label exact for filtering.

### Competition

- 无明显竞争
- 间接竞争
- 直接竞争
- 竞合可能
- 待确认

## Validation

Before export, verify:

- source-company count equals the company count in `全名单`;
- every company has a stable source key in working data;
- no source company is silently merged or removed;
- source-row count reconciles to unique-entity rows plus documented duplicate mappings;
- every row has a total and grade, and totals match the rubric;
- every complete-run row is `深度核实 / 标准核实 / 受阻`, with `仅初筛=0`;
- every row visibly contains the research-state label rather than leaving it only in summary statistics;
- every retained English public description has a Chinese translation;
- the Chinese overview, Chinese full translation, and English original are aligned to the same company;
- the English-original column contains English source text, not Chinese/Korean text or analyst-written fallback prose;
- blocked rows contain a specific blocker and source attempt;
- direct competitors are visibly marked;
- multiple public contacts are not silently collapsed to one;
- every named contact has source lineage and current-role evidence;
- source-only and low-confidence contacts are visibly distinguished from publicly confirmed contacts;
- no phone value is an HTML/CSS/version/date/tracking artifact;
- published email status is separate from deliverability verification;
- source URLs and verification dates support material claims;
- sorting is total descending with the stated tie-breakers;
- both worksheets pass formula-error scanning and visual inspection;
- no debug, inspection, or checkpoint sidecar is delivered.
