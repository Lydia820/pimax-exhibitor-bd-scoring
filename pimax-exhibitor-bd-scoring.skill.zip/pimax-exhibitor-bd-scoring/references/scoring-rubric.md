# Pimax exhibitor BD scoring rubric

Score six dimensions from 0 to 5, then convert each rating with the stated multiplier. The weighted total is 100.

Use whole-number ratings. Prefer the lower rating when evidence sits between two anchors. Record a one-sentence reason for each dimension or a compact combined rationale that makes every rating traceable.

## Shared rating meaning

| Rating | Meaning |
|---:|---|
| 0 | No supported value, clearly irrelevant, or materially incompatible for this dimension |
| 1 | Weak or remote possibility; little evidence |
| 2 | Limited fit; plausible but important gaps remain |
| 3 | Credible fit with a usable cooperation hypothesis |
| 4 | Strong fit supported by clear products, audience, or channel evidence |
| 5 | Exceptional fit with direct complementarity and a compelling near-term path |

## Dimensions

### 1. Product and ecosystem fit — 25 points

`rating × 5`

Assess how closely the company connects to high-end PCVR, VR games/content, VRChat/social VR, sim racing, flight simulation, cockpits, seats, controls, motion/haptics, location-based VR, specialist hardware, distribution, integration, or another useful Pimax ecosystem.

- 0: no meaningful connection;
- 1: general gaming, entertainment, or technology with no demonstrated VR/PCVR path;
- 2: adjacent offering or audience, but integration or relevance is uncertain;
- 3: clear complementary product, content, channel, or user group;
- 4: strong direct complement to Pimax hardware and buyers;
- 5: core ecosystem partner whose offering naturally benefits from or can showcase high-end Pimax headsets.

### 2. Commercial contribution potential — 25 points

`rating × 5`

Assess plausible contribution to orders, qualified leads, traffic, channel coverage, referrals, or measurable demand. Do not substitute company size for commercial potential.

- 0: no credible commercial path;
- 1: speculative awareness only;
- 2: modest or indirect lead/traffic potential;
- 3: credible route to leads, referrals, sales, or channel access;
- 4: strong access to relevant buyers or repeated commercial opportunities;
- 5: unusually strong and scalable potential to influence or generate Pimax demand.

### 3. Cooperation path clarity — 20 points

`rating × 4`

Assess whether a concrete, mutually useful next step can be described.

Examples include bundle or compatibility work, cross-referral, demo integration, affiliate or reseller cooperation, joint content, community programming, event activation, showroom deployment, or solution integration.

- 0: no appropriate cooperation path;
- 1: only a generic “partner together” idea;
- 2: a possible path exists but lacks a clear exchange of value;
- 3: one credible cooperation concept with identifiable benefits;
- 4: multiple concrete paths or a strong single path supported by current activity;
- 5: near-term, specific, mutually beneficial path with an evident reason to act now.

### 4. Audience and overseas-market overlap — 15 points

`rating × 3`

Assess overlap with overseas users likely to value Pimax: PCVR enthusiasts, high-end gaming hardware buyers, sim racers, flight-sim users, VRChat users, attraction operators, integrators, specialist businesses, and other supported segments.

- 0: no supported audience overlap;
- 1: broad consumer or B2B audience with minimal relevance;
- 2: partial overlap or unclear overseas reach;
- 3: clear relevant audience or market overlap;
- 4: strong concentration of relevant overseas buyers or operators;
- 5: highly aligned audience with strong purchase, deployment, or recommendation intent.

### 5. Influence and execution capacity — 10 points

`rating × 2`

Assess observable capacity to execute a partnership: established products, distribution, active community, customer footprint, current operations, partner history, or other credible signals.

- 0: inactive, unverifiable, or clearly unable to execute;
- 1: very limited evidence of current operation;
- 2: operating company but reach or delivery capability is unclear;
- 3: credible operating capacity and a usable channel or customer base;
- 4: strong reach, product maturity, distribution, or partnership execution;
- 5: exceptional, well-supported ability to scale a partnership.

### 6. Event actionability — 5 points

`rating × 1`

Assess whether the current event creates a practical reason or opportunity to engage.

- 0: not confirmed at the event or no usable event signal;
- 1: listed, but details are incomplete;
- 2: confirmed exhibitor with basic profile or booth evidence;
- 3: identifiable relevant event presence;
- 4: relevant demo, launch, session, or activation creates a timely opening;
- 5: high-value on-site engagement opportunity with a clear target and timely cooperation hook.

Do not punish a company merely because booth data is missing. Score the supported event opportunity.

## Total and priority band

| Total | Band | Default interpretation |
|---:|:---:|---|
| 75–100 | A | Priority engagement candidate |
| 60–74 | B | Worth further research or engagement |
| 40–59 | C | Monitor or pursue conditionally |
| 0–39 | D | Low priority or no current fit |

An unscored company has no band. Do not assign D merely because research is incomplete.

## Score status

- `正式`: company identity is verified; primary evidence supports the core fit and cooperation hypothesis; material score drivers are traceable.
- `暂定`: identity is verified, but one or more important commercial assumptions rely on limited or indirect evidence.
- `未评分`: evidence is insufficient, identity is unresolved, or research has not reached the scoring stage.

## Research confidence

- `高`: primary sources verify identity, relevant offering/audience, and the core cooperation rationale; material claims are current.
- `中`: primary sources verify identity and relevance, but reach, commercial value, or cooperation feasibility includes reasonable inference.
- `低`: evidence is sparse, dated, inaccessible, based mainly on listings/search snippets, or vulnerable to mistaken identity.

Confidence is not a score multiplier. Keep a high-potential but low-confidence candidate visible with a verification action.

Low confidence is also not permission to assume potential. If identity, business scope, market, or audience is unresolved, award points only for facts that remain supported after the questionable match is removed. A descriptive name or event-list presence can justify a weak provisional category or actionability score, but not unverified commercial reach, execution capacity, or an A/B priority.

## Competition handling

Record one of:

- `无明显竞争`
- `间接竞争`
- `直接竞争`
- `竞合可能`
- `待确认`

Do not subtract points automatically for competition. Score the supported commercial/ecosystem value, then route direct competitors and sensitive coopetition cases to `竞合审查`. State the conflict or overlap and avoid ordinary outreach recommendations.

If Pimax itself appears in the source list, mark it as `自有主体/来源对照`, not `直接竞争`, and do not rank it as an external BD prospect.

## Calibration checks

Before finalizing a batch:

1. Compare at least five likely A/B candidates, five borderline candidates, several competitors, and several irrelevant companies.
2. Check that a famous general-entertainment company does not outrank a smaller direct PCVR/simulation complement merely because of scale.
3. Check that missing data produces lower confidence or `未评分`, not an invented zero.
4. Check that the same audience or product fact has not been counted in several dimensions without a distinct reason.
5. Revisit thresholds after the first real batch if A or B becomes implausibly broad or narrow. Preserve the current rubric in the workbook so later changes remain auditable.
6. Inspect the highest-ranked rows for identity/domain/description consistency. A wrong same-name match must be removed before calibration, not compensated for with a lower confidence label.
