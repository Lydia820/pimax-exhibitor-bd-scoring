# Research quality controls

Use these controls for company identity, public descriptions, and contacts. They exist to prevent same-name search results from contaminating an otherwise complete workbook.

## 1. Separate source records from entities

Maintain three layers in working data:

1. source rows exactly as supplied;
2. reconciled entities used for research and ranking;
3. evidence records tied to the entity and source row.

Consolidate exact duplicates when they clearly represent the same entity. For other names, require evidence such as an official domain, legal name, event profile, product, geography, or corporate relationship. Report source-row count, unique-entity count, and consolidated duplicate count.

Never silently remove:

- venue areas, lounges, programs, categories, or placeholders;
- Pimax's own entity;
- repeated exhibitors with distinct legal entities;
- unresolved generic names.

## 2. Identity verification gate

Before accepting a website or search result, check at least two useful signals when available:

- company or brand name;
- game/product title or business category;
- geography or legal entity;
- event context;
- official email domain;
- official company social link pointing back to the same domain.

Reject the match when the result is a dictionary entry, unrelated school, personal page, generic marketplace, different industry, different country with no supporting link, or a third-party profile that does not establish identity.

For famous companies, use the canonical official site or official corporate page. Memory may guide the search but is not evidence.

### Contamination rule

When a match is rejected, clear all dependent fields obtained from it:

- website and description;
- emails and phone numbers;
- LinkedIn company and people;
- contact page;
- evidence links;
- market/geography inferred from the result.

Do not keep a contact or LinkedIn page from a website already determined to be the wrong entity.

## 3. Description alignment

Keep three different concepts:

- `企业中文概述`: analyst-written Chinese explanation for decision-making;
- `公开业务描述（中文完整翻译）`: complete translation of the retained English source;
- `公开业务描述（英文原文）`: the matching English source text.

The Chinese translation and English original must describe the same entity and the same passage. Do not label Chinese/Korean text as English original. Do not present an analyst-written fallback as public source text.

If no reliable English source exists:

- keep a useful Chinese overview based on verified evidence or clearly stated source-list inference;
- put an explicit unavailable statement in both description fields;
- state the attempted sources and blocker in `风险及待核实项`;
- use `暂定 + 低 + 受阻` when identity or business scope remains unresolved.

## 4. Contact provenance levels

Use one of these statuses for every retained contact or channel:

1. `公开来源已确认`: official page or public professional profile supports current company and role;
2. `源表候选，任职待复核`: supplied workbook contains the record but current public evidence was not found;
3. `低置信候选，勿直接录入`: source workbook itself marks the match low-confidence, or identity/industry/domain conflicts;
4. `仅公司公开商务渠道`: official general email, phone, form, or company LinkedIn only;
5. `未找到公开联系人`.

Source-sheet confidence such as `高(自动核)` remains source-provided metadata. Do not silently upgrade it to public verification.

For low-confidence contacts:

- retain them only when the user requested all source contacts;
- show the warning in the same contact line;
- do not use them as evidence of company identity or score;
- do not describe them as outreach-ready.

## 5. Email and phone hygiene

Accept an email only when its source and company relationship are visible. Reject:

- `example@...` or example domains;
- asset, telemetry, error-reporting, or build-system addresses;
- an email from a rejected same-name match;
- inferred email patterns.

Accept an official phone only from:

- a structured `tel:` link;
- a clearly labeled official contact block;
- an official exhibitor/contact page;
- a source-sheet record visibly tagged with its source confidence.

Do not harvest arbitrary digit strings from HTML. Dates, CSS values, version numbers, image sizes, tracking IDs, and page counters are not phone numbers.

## 6. Conservative blocked scoring

A blocked row is not unscored in the full-ranking workflow, but its score must use only supported facts.

- Participation may support event actionability.
- A descriptive company name may support a weak provisional category, not a high commercial score.
- Unverified fame, size, market, reach, or contacts contribute no points.
- A blocked row should normally remain below a verified company with direct PCVR or simulation relevance.
- Explain the attempted sources and the exact unresolved question.

Do not use a universal score cap; use the lower supported rating in each dimension and calibrate the ranked result.

## 7. Required audit sample

Before export, manually inspect at least:

- the highest-ranked 10 rows;
- five same-name or generic-name rows;
- five source-contact rows, including low-confidence candidates;
- all direct competitors and the Pimax self-row;
- several blocked rows from the top, middle, and bottom;
- all rows with unusually many emails or phone numbers.

Reject or correct any row where the description, domain, contact, geography, and company identity do not belong together.
